import "./footer.css";

function Footer() {
    return (
        <div className="footer">
            <label>Low Depot Inc.</label>
        </div>
    )
}

export default Footer;